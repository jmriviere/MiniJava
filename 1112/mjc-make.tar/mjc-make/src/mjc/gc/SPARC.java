package mjc.gc;

public class SPARC extends AbstractMachine {

	protected String getSuffixe() {
		return "s";
	}

}
