package mjc.gc;

public class X86 extends AbstractMachine {

	protected String getSuffixe() {
		return "s";
	}

}
