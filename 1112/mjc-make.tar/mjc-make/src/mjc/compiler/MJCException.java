package mjc.compiler;

public class MJCException extends Exception {
	private static final long serialVersionUID = 1L;

	public MJCException(String a) {
		super(a);
	}

}
