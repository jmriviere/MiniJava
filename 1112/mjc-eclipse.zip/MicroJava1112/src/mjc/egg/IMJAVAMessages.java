package mjc.egg;
public interface IMJAVAMessages {

  public static  int id_MJAVA_expected_token = 5505024;
  public static  int id_MJAVA_unexpected_token = 5505025;
  public static  int id_MJAVA_expected_eof = 5505026;
  }
