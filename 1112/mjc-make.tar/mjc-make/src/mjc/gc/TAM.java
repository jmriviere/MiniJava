package mjc.gc;

public class TAM extends AbstractMachine {

	public String getSuffixe() {
		return "tam";
	}

}
